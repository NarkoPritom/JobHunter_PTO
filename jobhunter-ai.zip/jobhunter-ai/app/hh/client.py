"""
HeadHunter (hh.ru) API client.

Search endpoint (GET /vacancies) is public — no auth required.
Submitting a response (POST /negotiations) requires an OAuth access token
issued to YOUR hh.ru account, plus your resume_id. See README.md for how to
get these (hh.ru app registration + OAuth flow — a one-time manual step,
hh.ru does not allow using someone else's credentials).
"""
from __future__ import annotations

import httpx
import structlog

from app.config.settings import settings

logger = structlog.get_logger(__name__)

HH_BASE_URL = "https://api.hh.ru"
USER_AGENT = "JobHunterAI/1.0 (personal use; contact via telegram)"


class HHClient:
    def __init__(self) -> None:
        self._client = httpx.AsyncClient(
            base_url=HH_BASE_URL,
            headers={"User-Agent": USER_AGENT},
            timeout=20.0,
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def search_vacancies(
        self,
        text: str,
        area: int | None = None,
        salary: int | None = None,
        schedule: str | None = None,  # "remote" | "flexible" | "fullDay"
        per_page: int = 50,
        page: int = 0,
    ) -> list[dict]:
        params: dict = {
            "text": text,
            "per_page": per_page,
            "page": page,
            "order_by": "publication_time",
        }
        if area is not None:
            params["area"] = area
        if salary is not None:
            params["salary"] = salary
            params["only_with_salary"] = True
        if schedule is not None:
            params["schedule"] = schedule

        resp = await self._retry_get("/vacancies", params=params)
        data = resp.json()
        return data.get("items", [])

    async def get_vacancy_details(self, vacancy_id: str) -> dict:
        resp = await self._retry_get(f"/vacancies/{vacancy_id}")
        return resp.json()

    async def submit_response(self, vacancy_id: str, message: str) -> bool:
        """Submit an actual application via hh.ru negotiations API.
        Requires settings.hh_access_token and settings.hh_resume_id."""
        if not settings.hh_access_token or not settings.hh_resume_id:
            logger.warning("hh_apply_skipped_no_credentials", vacancy_id=vacancy_id)
            return False

        headers = {"Authorization": f"Bearer {settings.hh_access_token}"}
        data = {
            "vacancy_id": vacancy_id,
            "resume_id": settings.hh_resume_id,
            "message": message,
        }
        resp = await self._client.post("/negotiations", headers=headers, data=data)
        if resp.status_code in (200, 201, 303):
            logger.info("hh_apply_success", vacancy_id=vacancy_id)
            return True
        logger.error("hh_apply_failed", vacancy_id=vacancy_id, status=resp.status_code, body=resp.text)
        return False

    async def _retry_get(self, path: str, params: dict | None = None, retries: int = 3) -> httpx.Response:
        last_exc: Exception | None = None
        for attempt in range(retries):
            try:
                resp = await self._client.get(path, params=params)
                if resp.status_code == 429:
                    logger.warning("hh_rate_limited", attempt=attempt)
                    continue
                resp.raise_for_status()
                return resp
            except httpx.HTTPError as exc:
                last_exc = exc
                logger.warning("hh_request_retry", attempt=attempt, error=str(exc))
        assert last_exc is not None
        raise last_exc
